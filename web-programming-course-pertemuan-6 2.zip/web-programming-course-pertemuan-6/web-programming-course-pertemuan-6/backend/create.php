<?php

include '../config/db.php';

if(isset($_POST['submit'])) {

    $name = $_POST['namei'];
    $price = $_POST['price'];
    $image = $_FILES['image']['name'];
    $tempImage = $_FILES['image']['tmp_name'];

    $uploadPath = "upload/";

    // Check if the "upload" directory exists
    if (!is_dir($uploadPath)) {
        mkdir($uploadPath, 0755, true);
    }

    $upload = move_uploaded_file($tempImage, $uploadPath . $image);

    if($upload) {
        $stmt = mysqli_prepare($db_connect, "INSERT INTO products (name, price, image) VALUES (?, ?, ?)");
        mysqli_stmt_bind_param($stmt, 'sss', $name, $price, $image);
        mysqli_stmt_execute($stmt);

        if(mysqli_stmt_affected_rows($stmt) > 0) {
            echo "Berhasil upload";
        } else {
            echo "Gagal upload ke database";
        }

        mysqli_stmt_close($stmt);
    } else {
        echo "Gagal upload file";
    }
}
?>
