<?php

include '../config/db.php'; // Adjust the path accordingly

if(isset($_GET['id'])) {
    $id = $_GET['id'];

    // Fetch the image file name associated with the product
    $cek_image = mysqli_query($db_connect, "SELECT image FROM products WHERE id = '$id'");
    $image = mysqli_fetch_assoc($cek_image)['image'];

    // Delete the product record from the database
    $delete_produk = "DELETE FROM products WHERE id='$id'";
    mysqli_query($db_connect, $delete_produk);

    // Delete the associated image file
    unlink("upload/$image");

    // Redirect to a different page or display a success message as needed
    echo '<META HTTP-EQUIV="Refresh" Content="0; URL=../show.php">';

    exit();
} else {
    // Handle the case where 'id' is not provided in the URL
    echo "Product ID not provided.";
}
?>
