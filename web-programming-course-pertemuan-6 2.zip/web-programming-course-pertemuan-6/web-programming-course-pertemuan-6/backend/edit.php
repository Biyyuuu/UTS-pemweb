<?php

include '../config/db.php'; // Adjust the path accordingly

if(isset($_POST['submit'])) {
    $id = $_GET['id'];
    $name = $_POST['namei'];
    $price = $_POST['price'];

    // Check if a new image file is uploaded
    if (!empty($_FILES['image']['name'])) {
        $image = $_FILES['image']['name'];
        $tempImage = $_FILES['image']['tmp_name'];

        // Remove the old image file
        $oldImageResult = mysqli_query($db_connect, "SELECT image FROM products WHERE id = '$id'");
        $oldImage = mysqli_fetch_assoc($oldImageResult)['image'];
        unlink("upload/$oldImage");

        // Upload the new image file
        move_uploaded_file($tempImage, "upload/$image");

        // Update the database with the new image file name
        $updateQuery = "UPDATE products SET name='$name', price='$price', image='$image' WHERE id='$id'";
    } else {
        // If no new image file, update without changing the image file
        $updateQuery = "UPDATE products SET name='$name', price='$price' WHERE id='$id'";
    }

    // Perform the database update
    mysqli_query($db_connect, $updateQuery);

    // Redirect to a different page or display a success message as needed
    echo '<META HTTP-EQUIV="Refresh" Content="0; URL=../show.php">';

    exit();
}
?>
