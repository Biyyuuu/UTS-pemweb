<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<?php

include 'config/db.php';
$id = $_GET['id'];

$sql = mysqli_query($db_connect,"SELECT * FROM products WHERE id = '$id' ");
while ($data=mysqli_fetch_array($sql,MYSQLI_ASSOC)) {
$name = $data['name'];
$price = $data['price'];
$image = $data['image'];
  }
  echo $image;
  ?>
<body>
    <h1>Tambah Produk</h1>
    <!-- <a href="show.php">Lihat data produk</a> -->
    <form action="backend/edit.php" method="post" enctype="multipart/form-data">
        <input type="text" name="namei" value="<?=$name?>" placeholder="input nama produk">
        <input type="number" name="price" value="<?=$price?>" placeholder="input harga produk">
        <!-- <input type="file" name="image" > -->
        <img src="backend/upload/<?= $image ?>" alt="Product Image" width="100">
        <input type="file" name="image">
        <input type="submit" value="simpan" name="submit">
    </form> 
</body>
</html>

